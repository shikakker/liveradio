package whoisegor.liveradio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveRadioApplicationTests {

	@Test
	void contextLoads() {
	}

}
