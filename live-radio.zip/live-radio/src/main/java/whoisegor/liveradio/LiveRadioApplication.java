package whoisegor.liveradio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveRadioApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiveRadioApplication.class, args);
	}

}
